const express = require("express");
const server = express();
const port = process.env.PORT_ADMIN || 3001;

server.listen(port, () => {
    console.log(`Aplicação Admin pronta para uso na port: ${port}`);
});

server.get("/", (req, res, next) => {
    res.send(`xAplicação Admin em Node.js`);
});